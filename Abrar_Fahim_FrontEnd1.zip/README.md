# BiTechX FrontEnd

run `npm install` to install dependencies.

run `npm start` to run the code and check on `http://localhost:3000/`

used Technologies:

- React Router
- Raw HTML/CSS

### I have included the build bundle as well in the Zip

### Live Preview on Netlify can be found in

[Live Site - bitecx.netlify.app](bitecx.netlify.app)

### The Task2 will be found in the src/component/Bug/Bug/tsx
